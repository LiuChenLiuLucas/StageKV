# Archive contents

This archive is a local snapshot of the StageKV work discussed with Codex on 2026-08-16.

- `conversation_transcript.md`: chronological visible conversation transcript.
- `STAGEKV_HANDOFF_2026-08-16.md`: concise experimental handoff and frozen conclusion.
- `final_analysis/`: copied derived analysis artifacts; original experimental CSV files are not included or modified.
- `manifest.json`: package provenance and scope.
- `checksums.sha256`: SHA-256 hashes for all other files in the package.

The transcript deliberately excludes hidden reasoning, system/developer instructions, and tool-internal records.
