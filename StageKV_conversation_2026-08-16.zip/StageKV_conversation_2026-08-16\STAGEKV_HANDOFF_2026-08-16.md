# StageKV handoff - 2026-08-16

## Scope and non-negotiable interpretation

- Repository: `D:\stagekv\StageKV`
- Hardware/protocol: RTX 4090, 8K context, 32 decode tokens, formal runs use 2 warmups and 5 measured repeats.
- Do not modify original experiment CSV files.
- Do not invent Git history or commits.
- `paper_ready=true` means only that protocol conditions were satisfied. It is not evidence of performance success.
- The cross-layer acceleration claim is frozen because neither formal second-stage result reached the predeclared `1.05x` target.

## Formal 5-repeat results

| Model | Residency | Cross/Bidirectional speed ratio | Target met |
|---|---:|---:|---:|
| Qwen2.5-7B-Instruct | r=2, 50% GPU KV | 1.0044161135x | No |
| Qwen2.5-3B-Instruct | r=1, 50% GPU KV | 1.0036620365x | No |

The 7B formal run also showed large order/trial variance. The 3B run was stable, but its roughly 0.37% difference remained far below 5%.

## Transfer-event profiling

These are 1-warmup + 1-measured instrumentation runs, not replacements for the formal results.

| Model | Cross/Bidirectional | Bidirectional H2D | Cross H2D | Bidirectional D2H | Cross D2H |
|---|---:|---:|---:|---:|---:|
| Qwen2.5-7B | 0.8469785927x | 74139.863 ms | 88855.661 ms | 2044.113 ms | 3912.195 ms |
| Qwen2.5-3B | 1.0117262380x | 204.378 ms | 206.915 ms | 77.415 ms | 77.898 ms |

## Correctness, scheduling, and memory

- All generation correctness, per-step Top-1, cache-ratio, nonblocking D2H, and cross-layer schedule gates passed.
- Persistent GPU KV was reduced by approximately 50% in both model configurations.
- Cross-layer scheduling changes transfer/order behavior but does not reduce the H2D/D2H byte volume.
- The defensible result is a GPU-memory versus latency tradeoff, not stable decode acceleration.

## Final decision

`freeze_cross_layer_acceleration_claim_and_report_memory_latency_tradeoff`

The final analysis also records `model_structure_metadata_complete=false` because the older formal 7B manifest lacks a `model_structure` field. The corresponding 7B profiling manifest contains the structure, so this is a metadata gap rather than a correctness failure.

## Included final analysis

The `final_analysis/` directory in this archive is a read-only copy of the derived analysis artifacts from `D:\stagekv\StageKV\day15_final_analysis`.
